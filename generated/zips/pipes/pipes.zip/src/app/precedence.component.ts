import { Component } from '@angular/core';

@Component({
  selector: 'app-precedence',
  templateUrl: './precedence.component.html'
})

export class PrecedenceComponent {
  title = 'Pipes and Precedence';
}
